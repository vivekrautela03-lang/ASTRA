# ✦ ASTRA — Personal AI Operating System & Desktop Assistant

ASTRA is a next-generation AI assistant built with **React 19**, **Three.js**, **Tailwind CSS**, **Electron**, and a **Native Python Intelligence Kernel**.

---

## 🌟 Key Architecture & Capabilities

* **✦ Living Plasma Energy Orb (`AstraOrb.tsx`):** 6-octave Fractal Brownian Motion (FBM) procedural plasma shader reacting to audio frequencies and system state.
* **✦ Transparent Floating Wake-Up Overlay (`AstraFloatingAssistant.tsx`):** Triggered by *"Hey Astra"*, keyboard shortcuts (`Alt+Space`), or tray activation.
* **✦ 21 Native Python System Tools:**
  * **Process Launcher (`open_app`):** Launch any application (*Chrome, Spotify, VS Code, Notepad, WhatsApp...*)
  * **System Telemetry (`system_status`):** Real-time CPU, RAM, GPU, and process metrics.
  * **Live Forecasts (`weather_report`):** Global weather reports.
  * **Web Intelligence (`web_search`):** Deep research, news lookup, price comparisons.
  * **Media Controller (`youtube_video`):** YouTube video searches and playback.
  * **Task Scheduler (`reminder`):** Windows Task Scheduler integration.
  * **Computer Control & Settings (`computer_settings`):** Volume, brightness, window commands.
* **✦ File Vault & Artifact Archive (`AstraFileVault.tsx`):** Saved chats, documents, generated images, and code snippets.
* **✦ Plugins & Integrations Center (`AstraPluginsCenter.tsx`):** Connect API keys and third-party tools.
* **✦ Dual Deployment (Web & Standalone Desktop):** Runs in the browser via Vite and packages as a standalone Windows `.exe` using Electron.

---

## 🚀 Getting Started

### 1. Install Node & Python Dependencies
```bash
npm install
pip install sounddevice pillow requests beautifulsoup4 psutil youtube-transcript-api send2trash
```

### 2. Run in Development Mode
* **Web Browser Version (Vite):**
  ```bash
  npm run dev
  ```
* **Desktop Application (Electron + Hot-Reload):**
  ```bash
  npm run electron
  ```

### 3. Build Windows Executable (`.exe`)
```bash
npm run dist
```
The generated `Astra.exe` and installer will be located in the `release/` directory.

---

## 📁 Repository Structure

```text
.
├── src/                          # Modern Liquid Glass React Frontend
│   ├── components/astra/         # Orb, Floating Assistant, Chat Screen, File Vault
│   ├── pages/Dashboard.tsx       # Master OS Workspace & Router
│   ├── services/                 # Tool dispatchers, automation bridges, wake-word
│   └── styles/                   # Glassmorphic CSS & Shaders
├── electron/                     # Electron Main Process, Window Manager, Preload
├── server/                       # Node Express Gateway & Python Tool Bridge
├── backend/                      # Security sandbox, telemetry, context engine
├── ai-assistant--main/           # Native Python Tool Action Implementations
├── public/                       # Assets, SVG icons, and models
├── package.json                  # Scripts & dependencies
└── vite.config.ts                # Vite build configuration
```

---

## 📄 License
MIT License — Built by Vivek Rautela & Team ASTRA.
