import type { VisionDetection } from '../types/eva';
import { jarvisSoundEngine } from './jarvisSoundEngine';

export class VoiceVisionEngine {
  public listeningActive: boolean = false;
  public wakeWordActive: boolean = false;
  private synth: SpeechSynthesis | null = typeof window !== 'undefined' ? window.speechSynthesis : null;
  private recognition: any = null;
  private wakeWordRecognition: any = null;
  private silenceTimer: any = null;
  private lastProcessedTranscript: string = '';
  private lastProcessedTime: number = 0;

  constructor() {
    if (typeof window !== 'undefined') {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        this.recognition = new SpeechRecognition();
        this.recognition.continuous = true;
        this.recognition.interimResults = true;
        this.recognition.lang = 'en-US';

        this.wakeWordRecognition = new SpeechRecognition();
        this.wakeWordRecognition.continuous = true;
        this.wakeWordRecognition.interimResults = true;
        this.wakeWordRecognition.lang = 'en-US';
      }

      // Pre-fetch voices
      if (this.synth && this.synth.onvoiceschanged !== undefined) {
        this.synth.onvoiceschanged = () => {
          this.synth?.getVoices();
        };
      }
    }
  }

  /**
   * Get natural human time-based greeting for ASTRA AI
   */
  public getGreeting(): string {
    const hour = new Date().getHours();
    let timeGreeting = 'Good morning';
    if (hour >= 12 && hour < 17) {
      timeGreeting = 'Good afternoon';
    } else if (hour >= 17 || hour < 4) {
      timeGreeting = 'Good evening';
    }
    return `Hmm, ${timeGreeting}, Vivek! Haan sun raha hu. Ask me any question, I will respond to every single one!`;
  }

  /**
   * Speak a quick, natural human backchannel acknowledgement ("Hmm", "Achha", "Sun raha hu")
   */
  public speakQuickAcknowledgement(): void {
    const acknowledgements = [
      'Hmm, achha...',
      'Haan Vivek, sun raha hu...',
      'Hmm, ok tell me...',
      'Achha, got it...',
      'Hmm, haan...'
    ];
    const phrase = acknowledgements[Math.floor(Math.random() * acknowledgements.length)];
    this.speak(phrase, 'bilingual');
  }

  /**
   * Clean text string for natural TTS reading (removes code blocks, markdown syntax)
   */
  public cleanTextForSpeech(text: string): string {
    return text
      .replace(/```[\s\S]*?```/g, 'I have generated the code script for you on screen.')
      .replace(/`([^`]+)`/g, '$1')
      .replace(/[*_~#>-]/g, ' ')
      .replace(/\[(.*?)\]\((.*?)\)/g, '$1')
      .replace(/\s+/g, ' ')
      .trim();
  }

  /**
   * High quality TTS Speech Synthesis with natural articulate human voice selection
   */
  public speak(text: string, _language: 'en' | 'hi' | 'bilingual' = 'bilingual', onEnd?: () => void): void {
    if (!this.synth) {
      if (onEnd) onEnd();
      return;
    }

    // Cancel any previous audio queue to prevent stuttering
    this.synth.cancel();
    jarvisSoundEngine.playClick();

    const cleanText = this.cleanTextForSpeech(text);
    if (!cleanText) {
      if (onEnd) onEnd();
      return;
    }

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = 1.0;
    utterance.pitch = 1.02; // Articulate, calm, natural human pitch
    utterance.volume = 1.0;

    const voices = this.synth.getVoices();
    // Select premium ultra-clear natural voice (Google Natural, Microsoft Natural, Google US/UK, Samantha, Victoria, Zira)
    const premiumVoice = voices.find(v => 
      v.name.includes('Natural') ||
      (v.name.includes('Google') && (v.name.includes('UK') || v.name.includes('US') || v.name.includes('English'))) ||
      v.name.includes('Samantha') || 
      v.name.includes('Victoria') || 
      v.name.includes('Zira') || 
      v.name.includes('Karen') ||
      v.name.includes('Google हिन्दी')
    ) || voices.find(v => v.lang.startsWith('en') || v.lang.startsWith('hi')) || voices[0];

    if (premiumVoice) {
      utterance.voice = premiumVoice;
    }

    utterance.onend = () => {
      if (onEnd) onEnd();
    };

    utterance.onerror = (e) => {
      console.warn('[ASTRA TTS Warning] Speech synthesis interrupted:', e);
      this.synth?.cancel();
      if (onEnd) onEnd();
    };

    this.synth.speak(utterance);
  }

  /**
   * Stop active speech synthesis
   */
  public stopSpeaking(): void {
    if (this.synth) {
      this.synth.cancel();
    }
  }

  /**
   * Continuous Speech Recognition Listener with Guaranteed Response Trigger
   */
  public startListening(onResult: (transcript: string, isFinal: boolean) => void): void {
    if (!this.recognition) {
      console.warn('[ASTRA Speech Recognition] Web Speech API unavailable');
      return;
    }

    try {
      this.stopWakeWordListener();
      jarvisSoundEngine.playHologramActivation();
      this.listeningActive = true;

      this.recognition.onresult = (event: any) => {
        let interim = '';
        let final = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            final += event.results[i][0].transcript;
          } else {
            interim += event.results[i][0].transcript;
          }
        }

        const now = Date.now();

        if (final.trim()) {
          const cleanFinal = final.trim();
          if (this.silenceTimer) clearTimeout(this.silenceTimer);
          
          if (cleanFinal !== this.lastProcessedTranscript || now - this.lastProcessedTime > 1500) {
            this.lastProcessedTranscript = cleanFinal;
            this.lastProcessedTime = now;
            onResult(cleanFinal, true);
          }
        } else if (interim.trim()) {
          const cleanInterim = interim.trim();
          onResult(cleanInterim, false);
          
          if (this.silenceTimer) clearTimeout(this.silenceTimer);
          this.silenceTimer = setTimeout(() => {
            if (cleanInterim !== this.lastProcessedTranscript || now - this.lastProcessedTime > 1500) {
              this.lastProcessedTranscript = cleanInterim;
              this.lastProcessedTime = Date.now();
              onResult(cleanInterim, true);
            }
          }, 1200);
        }
      };

      this.recognition.onerror = (event: any) => {
        console.warn('[ASTRA STT Error]:', event.error);
        if (event.error !== 'aborted') {
          setTimeout(() => {
            if (this.listeningActive) {
              try { this.recognition.start(); } catch { /* Restart safely */ }
            }
          }, 400);
        }
      };

      this.recognition.onend = () => {
        if (this.listeningActive) {
          setTimeout(() => {
            try { this.recognition.start(); } catch { /* Restart safely */ }
          }, 200);
        }
      };

      this.recognition.start();
    } catch (e) {
      console.warn('[ASTRA STT Listener Exception]', e);
    }
  }

  /**
   * Stop listening
   */
  public stopListening(): void {
    this.listeningActive = false;
    if (this.recognition) {
      try {
        this.recognition.stop();
      } catch {
        // Ignore
      }
    }
  }

  /**
   * Wake-Word Background Listener ("Hey ASTRA" / "ASTRA" / "FRIDAY" / "Computer")
   */
  public startWakeWordListener(onWakeWordDetected: () => void): void {
    if (!this.wakeWordRecognition || this.listeningActive) return;

    try {
      this.wakeWordActive = true;
      this.wakeWordRecognition.onresult = (event: any) => {
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          const transcript = event.results[i][0].transcript.toLowerCase();
          if (
            transcript.includes('astra') || 
            transcript.includes('hey astra') || 
            transcript.includes('friday') || 
            transcript.includes('eva') || 
            transcript.includes('wake up') || 
            transcript.includes('computer')
          ) {
            this.stopWakeWordListener();
            jarvisSoundEngine.playHologramActivation();
            onWakeWordDetected();
            break;
          }
        }
      };

      this.wakeWordRecognition.onend = () => {
        if (this.wakeWordActive && !this.listeningActive) {
          try { this.wakeWordRecognition.start(); } catch { /* Ignore */ }
        }
      };

      this.wakeWordRecognition.start();
    } catch {
      // Background listener silent catch
    }
  }

  public stopWakeWordListener(): void {
    this.wakeWordActive = false;
    if (this.wakeWordRecognition) {
      try {
        this.wakeWordRecognition.stop();
      } catch {
        // Ignore
      }
    }
  }

  public getLiveDetections(): VisionDetection[] {
    return [
      { id: 'det-1', label: 'Vivek (User Face)', confidence: 0.99, box: { x: 200, y: 150, width: 420, height: 480 }, category: 'person' },
      { id: 'det-2', label: 'Primary Workstation Screen', confidence: 0.96, box: { x: 50, y: 50, width: 1200, height: 700 }, category: 'interface' },
      { id: 'det-3', label: 'ASTRA 3D Grid Core', confidence: 0.98, box: { x: 600, y: 100, width: 1000, height: 750 }, category: 'hologram' }
    ];
  }
}

export const voiceVisionEngine = new VoiceVisionEngine();
